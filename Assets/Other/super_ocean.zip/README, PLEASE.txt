This font is for PERSONAL USE ONLY!.

If you want to use this font for commercial purposes, you will need to purchase a commercial license. You can purchase a commercial license at 

https://allsuperfont.com/product/super-ocean/

Introducing "Super Ocean": A Casual Dive into the Deep End
Super Ocean is a typeface designed to evoke the carefree spirit of the open sea, inviting you to dive into a world of casual elegance.